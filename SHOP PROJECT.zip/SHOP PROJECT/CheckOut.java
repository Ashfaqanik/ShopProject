import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class CheckOut extends JFrame implements ActionListener{
    private String userId;
    private JPanel panel;
    private JLabel welcomeL, nameL, namesL, phoneL, addressL, payL;
    private JTextField phoneTF, addressTF;
    private JButton back, logOut, confirm;
    private JRadioButton r1, r2, r3;
    private ButtonGroup bg1;

    public CheckOut(String userId){
        super("Check Out");

        this.userId = userId;
        this.setSize(1380, 780);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(36, 50, 61));

        welcomeL = new JLabel(userId);
        welcomeL.setBounds(530, 50, 400, 40);
        welcomeL.setFont(new Font("Siyam Rupali", Font.BOLD, 45));
        welcomeL.setForeground(Color.WHITE);
        panel.add(welcomeL);

        nameL = new JLabel("Name : ");
        nameL.setBounds(450, 200, 150, 30);
        nameL.setFont(new Font("Cambria", Font.BOLD, 30));
        nameL.setForeground(Color.WHITE);
        panel.add(nameL);

        namesL = new JLabel();
        namesL.setBounds(560, 200, 800, 30);
        namesL.setFont(new Font("Cambria", Font.BOLD, 25));
        namesL.setForeground(Color.WHITE);
        panel.add(namesL);

        phoneL = new JLabel("Phone Number : ");
        phoneL.setBounds(322, 270, 300, 30);
        phoneL.setFont(new Font("Cambria", Font.BOLD, 30));
        phoneL.setForeground(Color.WHITE);
        panel.add(phoneL);

        phoneTF = new JTextField();
        phoneTF.setBounds(560, 270, 200, 30);
        phoneTF.setFont(new Font("Cambria", Font.BOLD, 20));
        panel.add(phoneTF);

        addressL = new JLabel("Address : ");
        addressL.setBounds(415, 340, 500, 30);
        addressL.setFont(new Font("Cambria", Font.BOLD, 30));
        addressL.setForeground(Color.WHITE);
        panel.add(addressL);

        addressTF = new JTextField();
        addressTF.setBounds(560, 340, 200, 80);
        addressTF.setFont(new Font("Cambria", Font.BOLD, 25));
        panel.add(addressTF);

        payL = new JLabel("Payment : ");
        payL.setBounds(407, 460, 150, 30);
        payL.setFont(new Font("Cambria", Font.BOLD, 30));
        payL.setForeground(Color.WHITE);
        panel.add(payL);

        r1 = new JRadioButton("Bkash");
        r1.setBounds(560, 460, 150, 30);
        r1.setFont(new Font("Cambria", Font.BOLD, 20));
        r1.setBackground(new Color(36, 50, 61));
        r1.setForeground(Color.WHITE);
		panel.add(r1);
		
		r2 = new JRadioButton("Card");
        r2.setBounds(560, 500, 150, 30);
        r2.setFont(new Font("Cambria", Font.BOLD, 20));
        r2.setBackground(new Color(36, 50, 61));
        r2.setForeground(Color.WHITE);
		panel.add(r2);
		
		r3 = new JRadioButton("Cash on Delivery");
        r3.setBounds(560, 540, 200, 30);
        r3.setFont(new Font("Cambria", Font.BOLD, 20));
        r3.setBackground(new Color(36, 50, 61));
        r3.setForeground(Color.WHITE);
		panel.add(r3);
		
		bg1 = new ButtonGroup();
		bg1.add(r1);
		bg1.add(r2);
        bg1.add(r3);
        
        confirm = new JButton("CONFIRM");
        confirm.setBounds(500, 600, 250, 40);
        confirm.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        confirm.setBackground(new Color(51, 194, 78));
        confirm.setForeground(Color.WHITE);
        confirm.addActionListener(this);
        panel.add(confirm);

        logOut = new JButton("LOGOUT");
        logOut.setBounds(1155, 45, 100, 40);
        logOut.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        logOut.setBackground(new Color(26, 177, 136));
        logOut.setForeground(Color.WHITE);
        logOut.addActionListener(this);
        panel.add(logOut);

        back = new JButton("BACK");
        back.setBounds(100, 45, 100, 40);
        back.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        back.setBackground(new Color(26, 177, 136));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        panel.add(back);

        loadDB();

        this.add(panel);
    }

    public void actionPerformed(ActionEvent ae){
        String str = ae.getActionCommand();

        if(str.equals(logOut.getText())){
            Login li = new Login();
            li.setVisible(true);
            this.setVisible(false);
        }

        else if(str.equals(back.getText())){
            ProductList pl = new ProductList(userId);
            pl.setVisible(true);
            this.setVisible(false);
        }

        else if(str.equals(confirm.getText())){
            CustomerHome ch = new CustomerHome(userId);
            ch.setVisible(true);
            this.setVisible(false);
        }

        else{}
    }

    public void loadDB(){
        String query = "SELECT `customerName`, `phoneNumber`, `address` FROM `customer` WHERE `userId`='"+userId+"';";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        System.out.println(query);

        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");
                       
            String cname = null;
            String phone = null; 
            String address = null;
            boolean flag = false;

            while(rs.next()){
                cname = rs.getString("customerName");
                phone = rs.getString("phoneNumber");
                address = rs.getString("address");
                flag = true;

                namesL.setText(cname);
                phoneTF.setText(phone);
                addressTF.setText(address);
            }

            if(!flag){
                namesL.setText("");
                phoneTF.setText("");
                addressTF.setText("");
            }
        } catch(Exception ex){
            System.out.println("Exception : " + ex.getMessage());
        }

        finally{
            try{
                if(rs != null)
					rs.close();

                if(st != null)
					st.close();

                if(con != null)
					con.close();
            } catch(Exception ex){}
        }
    }
}