import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ProductInfo extends JFrame implements ActionListener{
    private JPanel panel;
    private String userId;
    private int dquantity = 0;
    private JLabel userL, nameL, priceL, quantityL;
    private JTextField userTF, nameTF, priceTF, quantityTF;
    private JButton search, update, delete, back, logOut, refresh, add;

    public ProductInfo(String userId){
        super("Products");

        this.userId = userId;
        this.setSize(1370, 750);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(36, 50, 61));

        Font f1 = new Font("Cambria", Font.BOLD, 20);

        refresh = new JButton("REFRESH");
		refresh.setBounds(520, 50, 275, 45);
		refresh.setFont(f1);
		refresh.setBackground(new Color(51, 194, 78));
        refresh.setForeground(Color.WHITE);
        refresh.addActionListener(this);
        panel.add(refresh);

        userL = new JLabel("productId :");
        userL.setBounds(485, 210, 150, 30);
        userL.setFont(new Font("Cambria", Font.BOLD, 25));
        userL.setForeground(Color.WHITE);
        panel.add(userL);

        userTF = new JTextField();
        userTF.setBounds(650, 210, 200, 30);
        userTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(userTF);

        search = new JButton("SEARCH");
		search.setBounds(890, 210, 150, 25);
		search.setFont(new Font("Cambria", Font.BOLD, 20));
		search.setBackground(new Color(51, 194, 78));
        search.setForeground(Color.WHITE);
        search.addActionListener(this);
        panel.add(search);
        
        nameL = new JLabel("Product Name :");
        nameL.setBounds(438, 270, 200, 30);
        nameL.setFont(new Font("Cambria", Font.BOLD, 25));
        nameL.setForeground(Color.WHITE);
        panel.add(nameL);

        nameTF = new JTextField();
        nameTF.setBounds(650, 270, 200, 30);
        nameTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(nameTF);

        priceL = new JLabel("Price :");
        priceL.setBounds(541, 330, 150, 30);
        priceL.setFont(new Font("Cambria", Font.BOLD, 25));
        priceL.setForeground(Color.WHITE);
        panel.add(priceL);

        priceTF = new JTextField();
        priceTF.setBounds(650, 330, 200, 30);
        priceTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(priceTF);

        quantityL = new JLabel("Quantity :");
        quantityL.setBounds(501, 390, 150, 30);
        quantityL.setFont(new Font("Cambria", Font.BOLD, 25));
        quantityL.setForeground(Color.WHITE);
        panel.add(quantityL);

        quantityTF = new JTextField();
        quantityTF.setBounds(650, 390, 200, 30);
        quantityTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(quantityTF);

        add = new JButton("ADD");
		add.setBounds(450, 500, 135, 45);
		add.setFont(f1);
		add.setBackground(new Color(51, 194, 78));
        add.setForeground(Color.WHITE);
        add.addActionListener(this);
        panel.add(add);
        
        update = new JButton("UPDATE");
		update.setBounds(600, 500, 150, 45);
		update.setFont(f1);
		update.setBackground(new Color(51, 194, 78));
        update.setForeground(Color.WHITE);
        update.setEnabled(false);
        update.addActionListener(this);
        panel.add(update);
        
        delete = new JButton("DELETE");
		delete.setBounds(765, 500, 150, 45);
		delete.setFont(f1);
		delete.setBackground(new Color(255, 51, 51));
        delete.setForeground(Color.WHITE);
        delete.setEnabled(false);
        delete.addActionListener(this);
        panel.add(delete);

        logOut = new JButton("LOGOUT");
        logOut.setBounds(1175, 45, 100, 40);
        logOut.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        logOut.setBackground(new Color(26, 177, 136));
        logOut.setForeground(Color.WHITE);
        logOut.addActionListener(this);
        panel.add(logOut);

        back = new JButton("BACK");
        back.setBounds(80, 45, 100, 40);
        back.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        back.setBackground(new Color(26, 177, 136));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        panel.add(back);

        this.add(panel);
    }

    public void actionPerformed(ActionEvent ae){
        String text = ae.getActionCommand();

        if(text.equals(back.getText())){
            checkEmployee();
        }

        else if(text.equals(refresh.getText())){
            update.setEnabled(false);
            delete.setEnabled(false);
            add.setEnabled(true);
            userTF.setEnabled(true);
            userTF.setText("");
            nameTF.setText("");
			priceTF.setText("");
			quantityTF.setText("");
        }

        else if(text.equals(logOut.getText())){
            Login li = new Login();
            li.setVisible(true);
            this.setVisible(false);
        }

        else if(text.equals(search.getText())){
            loadDB();
        }

        else if(text.equals(add.getText())){
            insertDB();
        }

        else if(text.equals(delete.getText())){
            deleteDB();
        }

        else if(text.equals(update.getText())){
            updateDB();
        }

        else{}
    }

    public void insertDB(){
        String newId = userTF.getText();
        String newName = nameTF.getText();
        Double newPrice = Double.parseDouble(priceTF.getText());
        int newQuantity = Integer.parseInt(quantityTF.getText());

        String query = "INSERT INTO product VALUES ('"+newId+"','"+newName+"',"+newPrice+","+newQuantity+");";
		System.out.println(query);
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query);
			stm.close();
			con.close();
            JOptionPane.showMessageDialog(this, "Product Added!");
            
            update.setEnabled(false);
            delete.setEnabled(false);
            add.setEnabled(true);
            userTF.setEnabled(true);
			userTF.setText("");
			nameTF.setText("");
			priceTF.setText("");
			quantityTF.setText("");
        } catch(Exception ex){
            JOptionPane.showMessageDialog(this, "Oops!");
        }
    }

    public void getQuantity(){
        String loadId = userTF.getText();
        String query = "SELECT `availableQuantity` FROM `product` WHERE `productId`='"+loadId+"';";     
        Connection con = null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
        System.out.println(query);
        
        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");

            while(rs.next()){
                dquantity = rs.getInt("availableQuantity");  
            }
        } catch(Exception e){}

        finally{
            try{
                if(rs!=null)
					rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            } catch(Exception ex){}
        }
    }

    public void updateDB(){
        String loadId = userTF.getText();
		String newName = nameTF.getText();
		Double newPrice = 0.0;
        int newQuantity = 0;
        
        try{
            getQuantity();
            newPrice = Double.parseDouble(priceTF.getText());
            newQuantity = Integer.parseInt(quantityTF.getText()) + dquantity;
        } catch(Exception e){}

        String query = "UPDATE product SET productName='"+newName+"', price = "+newPrice+", availableQuantity = "+newQuantity+" WHERE productId='"+loadId+"'";	
        Connection con=null;//for connection
        Statement st = null;//for query execution
        System.out.println(query);
        
        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			st = con.createStatement();//create statement
			st.executeUpdate(query);
			st.close();
			con.close();
            JOptionPane.showMessageDialog(this, "Product Updated!");
            
            update.setEnabled(false);
            delete.setEnabled(false);
            add.setEnabled(true);
            userTF.setEnabled(true);
			userTF.setText("");
			nameTF.setText("");
			priceTF.setText("");
			quantityTF.setText("");
        } catch(Exception ex){}
    }

    public void loadDB(){
        String loadId = userTF.getText();
        String query = "SELECT `productName`, `price`, `availableQuantity` FROM `product` WHERE `productId`='"+loadId+"';";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        System.out.println(query);

        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");
                       
            String pname = null;
            double price = 0.0; 
            int quantity = 0;
            boolean flag = false;

            while(rs.next()){
                pname = rs.getString("productName");
                price = rs.getDouble("price");
                quantity = rs.getInt("availableQuantity");
                flag = true;

                nameTF.setText(pname);
                priceTF.setText("" + price);
                quantityTF.setText("" + quantity);
                userTF.setEnabled(false);
                update.setEnabled(true);
                delete.setEnabled(true);
                add.setEnabled(false);
            }

            if(!flag){
                nameTF.setText("");
                priceTF.setText("");
                quantityTF.setText("");
            }
        } catch(Exception ex){
            System.out.println("Exception : " + ex.getMessage());
        }

        finally{
            try{
                if(rs != null)
					rs.close();

                if(st != null)
					st.close();

                if(con != null)
					con.close();
            } catch(Exception ex){}
        }
    }

    public void checkEmployee(){
        String query = "SELECT `role` FROM `employee` WHERE `userId`='"+userId+"';";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        System.out.println(query);

        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");

            while(rs.next()){
                String role = rs.getString("role");

                if(role.equals("Employee")){
                    EmployeeHome eh = new EmployeeHome(userId);
                    eh.setVisible(true);
                    this.setVisible(false);
                }

                else if(role.equals("Manager")){
                    ManagerHome mh = new ManagerHome(userId);
                    mh.setVisible(true);
                    this.setVisible(false);
                }

                else{}
            }
        } catch(Exception ex){}

        finally{
            try{
                if(rs != null)
                    rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            } catch(Exception ex){}
        }
    }

    public void deleteDB(){
        String loadId = userTF.getText();
		String query = "DELETE from product WHERE productId='"+loadId+"';";
		System.out.println(query);
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query);
			stm.close();
			con.close();
            JOptionPane.showMessageDialog(this, "Product Deleted!");
            
            update.setEnabled(false);
            delete.setEnabled(false);
            add.setEnabled(true);
            userTF.setEnabled(true);
			userTF.setText("");
			nameTF.setText("");
			priceTF.setText("");
			quantityTF.setText("");
        } catch(Exception ex){}
    }
}