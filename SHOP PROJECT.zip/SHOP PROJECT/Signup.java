import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Signup extends JFrame implements ActionListener{
    private JTextField userTF, passTF, nameTF, phoneTF, addressTF;
    private JButton signin, back;
    private ImageIcon img;
    private JLabel welcomeL, userL, passL, nameL, phoneL, addressL, imgL, formatL;
    private JPanel panel;

    public Signup(){
        super("SignUp Form");

        this.setSize(1370, 750);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(36, 50, 61));

        Font f1 = new Font("Cambria", Font.BOLD, 20);

        img = new ImageIcon("smile.gif");
		imgL = new JLabel(img);
		imgL.setBounds(575, 5, 150, 150);
        panel.add(imgL);
        
        welcomeL = new JLabel("WELCOME!");
        welcomeL.setBounds(550, 150, 300, 50);
        welcomeL.setFont(new Font("Siyam Rupali", Font.BOLD, 40));
        welcomeL.setForeground(Color.WHITE);
        panel.add(welcomeL);

        nameL = new JLabel("Full Name :");
        nameL.setBounds(480, 250, 300, 30);
        nameL.setFont(new Font("Cambria", Font.BOLD, 30));
        nameL.setForeground(Color.WHITE);
        panel.add(nameL);

        nameTF = new JTextField();
        nameTF.setBounds(660, 250, 200, 30);
        nameTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(nameTF);

        userL = new JLabel("userId :");
        userL.setBounds(528, 300, 300, 30);
        userL.setFont(new Font("Cambria", Font.BOLD, 30));
        userL.setForeground(Color.WHITE);
        panel.add(userL);

        userTF = new JTextField();
        userTF.setBounds(660, 300, 200, 30);
        userTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(userTF);

        passL = new JLabel("password :");
        passL.setBounds(482, 350, 300, 30);
        passL.setFont(new Font("Cambria", Font.BOLD, 30));
        passL.setForeground(Color.WHITE);
        panel.add(passL);

        passTF = new JTextField();
        passTF.setBounds(660, 350, 200, 30);
        passTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(passTF);

        phoneL = new JLabel("Phone Number :");
        phoneL.setBounds(407, 400, 300, 30);
        phoneL.setFont(new Font("Cambria", Font.BOLD, 30));
        phoneL.setForeground(Color.WHITE);
        panel.add(phoneL);

        phoneTF = new JTextField();
        phoneTF.setBounds(660, 400, 200, 30);
        phoneTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(phoneTF);

        formatL = new JLabel("+88017XXXXXXXX");
        formatL.setBounds(875, 400, 300, 30);
        formatL.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        formatL.setForeground(Color.WHITE);
        panel.add(formatL);

        addressL = new JLabel("address :");
        addressL.setBounds(504, 450, 300, 30);
        addressL.setFont(new Font("Cambria", Font.BOLD, 30));
        addressL.setForeground(Color.WHITE);
        panel.add(addressL);

        addressTF = new JTextField();
        addressTF.setBounds(660, 450, 200, 80);
        addressTF.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        panel.add(addressTF);

        back = new JButton("BACK");
		back.setBounds(535, 580, 135, 45);
		back.setFont(f1);
		back.setBackground(new Color(51, 194, 78));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
		panel.add(back);

		signin = new JButton("SIGN IN");
		signin.setBounds(700, 580, 135, 45);
		signin.setFont(f1);
		signin.setBackground(new Color(51, 194, 78));
		signin.setForeground(Color.WHITE);
		signin.addActionListener(this);
		panel.add(signin);

        this.add(panel);
    }

    public void actionPerformed(ActionEvent ae){
        String text = ae.getActionCommand();

		if(text.equals(back.getText())){
			Login lg = new Login();
            lg.setVisible(true);
            this.setVisible(false);
        }
        
        else if(text.equals(signin.getText())){
            insertDB();
            CustomerHome ch = new CustomerHome(userTF.getText());
            ch.setVisible(true);
            this.setVisible(false);
        }

        else{}
    }

    public void insertDB(){
        String newUser = userTF.getText();
        String newName = nameTF.getText();
        String newPass = passTF.getText();
        String newPhone = phoneTF.getText();
        String newAddress = addressTF.getText();
        int status = 1;

        String query1 = "INSERT INTO customer VALUES ('"+newUser+"','"+newName+"','"+ newPhone+"','"+newAddress+"');";
        String query2 = "INSERT INTO login VALUES ('"+newUser+"','"+newPass+"',"+status+");";
        System.out.println(query1);
        System.out.println(query2);
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query1);
			stm.execute(query2);
			stm.close();
			con.close();
			JOptionPane.showMessageDialog(this, "welcome to TAZ shop");
        } catch(Exception ex){
            JOptionPane.showMessageDialog(this, "Oops!");
        }
    }
}