import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.DbUtils;

public class OrderList extends JFrame implements ActionListener{
    private String userId;
    private JLabel welcomeL, idL, nameL, namesL;
    private JTextField idTF;
    private JButton back, logOut;
    private JTable table;
	private JScrollPane tableScrollPane;
    private JPanel panel;

    public OrderList(String userId){
        super("Orders");

        this.userId = userId;
        this.setSize(1380, 750);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(36, 50, 61));

        welcomeL = new JLabel(userId);
        welcomeL.setBounds(530, 50, 400, 40);
        welcomeL.setFont(new Font("Siyam Rupali", Font.BOLD, 35));
        welcomeL.setForeground(Color.WHITE);
        panel.add(welcomeL);

        idL = new JLabel("ID :");
        idL.setBounds(520, 150, 100, 35);
        idL.setFont(new Font("Cambria", Font.BOLD, 30));
        idL.setForeground(Color.WHITE);
        panel.add(idL);

        idTF = new JTextField();
        idTF.setBounds(580, 150, 120, 35);
        idTF.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        idTF.addKeyListener(new KeyAdapter(){
            public void keyReleased(KeyEvent ke){
                loadData();
            }
        });
        panel.add(idTF);

        nameL = new JLabel("NAME :");
        nameL.setBounds(730, 150, 100, 35);
        nameL.setFont(new Font("Cambria", Font.BOLD, 30));
        nameL.setForeground(Color.WHITE);
        panel.add(nameL);

        namesL = new JLabel();
        namesL.setBounds(840, 150, 500, 35);
        namesL.setFont(new Font("Cambria", Font.BOLD, 30));
        namesL.setForeground(Color.WHITE);
        panel.add(namesL);

        String [][]row = {};
		String []col = {};
		
		table = new JTable(row, col);
		tableScrollPane = new JScrollPane(table);
		tableScrollPane.setBounds(350, 220, 700, 600);
        panel.add(tableScrollPane);
        
        showTableData();

        logOut = new JButton("LOGOUT");
        logOut.setBounds(1155, 45, 100, 40);
        logOut.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        logOut.setBackground(new Color(26, 177, 136));
        logOut.setForeground(Color.WHITE);
        logOut.addActionListener(this);
        panel.add(logOut);

        back = new JButton("BACK");
        back.setBounds(100, 45, 100, 40);
        back.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        back.setBackground(new Color(26, 177, 136));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        panel.add(back);

        this.add(panel);
    }

    public void actionPerformed(ActionEvent ae){
        String str = ae.getActionCommand();

        if(str.equals(logOut.getText())){
            Login li = new Login();
            li.setVisible(true);
            this.setVisible(false);
        }

        else if(str.equals(back.getText())){
            CustomerHome ch = new CustomerHome(userId);
            ch.setVisible(true);
            this.setVisible(false);
        }
    }

    public void showTableData(){
        String query = "SELECT `purchaseId`, `productId`, `quantity`, `amount`, `purchaseDate` FROM `purchaseinfo` WHERE `userId`='"+userId+"';";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        System.out.println(query);

        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");

            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch(Exception ex){}

        finally{
            try{
                if(rs != null)
					rs.close();

                if(st != null)
					st.close();

                if(con != null)
					con.close();
            } catch(Exception ex){}
        }
    }

    public void loadData(){
        String loadId = idTF.getText();
        String query = "SELECT `productName` FROM `product` WHERE `productId`='"+loadId+"';";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        System.out.println(query);

        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");
            
            String pname = null;
            boolean flag = false;

            while(rs.next()){
                pname = rs.getString("productName");
                flag = true;

                namesL.setText(pname);
            }

            if(!flag){
                namesL.setText("");
            }
        } catch(Exception ex){
            System.out.println("Exception : " + ex.getMessage());
        }

        finally{
            try{
                if(rs != null)
					rs.close();

                if(st != null)
					st.close();

                if(con != null)
					con.close();
            } catch(Exception ex){}
        }
    }
}