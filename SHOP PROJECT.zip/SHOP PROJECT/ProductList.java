import java.lang.*;
import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.time.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.DbUtils;

public class ProductList extends JFrame implements ActionListener{
    private String userId;
    private JLabel welcomeL, pidL, pnameL, amountL, quantityL, aquantityL, priceL, spriceL, pnameTF;
    private JTextField pidTF, amountTF;
    private JButton addCart, loadProduct, back, logOut, refresh, checkOut;
    private double price = 0.0;
    private int quantity = 0;
    private JTable table;
	private JScrollPane tableScrollPane;
    private JPanel panel;

    Random rand = new Random();
    LocalDate localDate = LocalDate.now();

    public ProductList(String userId){
        super("Product List");

        this.userId = userId;
        this.setSize(1380, 780);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(36, 50, 61));

        welcomeL = new JLabel(userId);
        welcomeL.setBounds(530, 50, 400, 40);
        welcomeL.setFont(new Font("Siyam Rupali", Font.BOLD, 45));
        welcomeL.setForeground(Color.WHITE);
        panel.add(welcomeL);

        refresh = new JButton("REFRESH");
        refresh.setBounds(180, 200, 170, 40);
        refresh.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        refresh.setBackground(new Color(51, 194, 78));
        refresh.setForeground(Color.WHITE);
        refresh.addActionListener(this);
        panel.add(refresh);

        loadProduct = new JButton("PRODUCT LIST");
        loadProduct.setBounds(730, 200, 300, 40);
        loadProduct.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        loadProduct.setBackground(new Color(255, 51, 51));
        loadProduct.setForeground(Color.WHITE);
        loadProduct.addActionListener(this);
        panel.add(loadProduct);

        String [][]row = {};
		String []col = {};
		
		table = new JTable(row, col);
		tableScrollPane = new JScrollPane(table);
		tableScrollPane.setBounds(700, 260, 350, 450);
        panel.add(tableScrollPane);
        
        showTableData();

        pidL = new JLabel("ProuductId* :");
        pidL.setBounds(50, 290, 200, 35);
        pidL.setFont(new Font("Cambria", Font.BOLD, 30));
        pidL.setForeground(Color.WHITE);
        panel.add(pidL);

        pidTF = new JTextField();
        pidTF.setBounds(270, 290, 200, 35);
        pidTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        pidTF.addKeyListener(new KeyAdapter(){
            public void keyReleased(KeyEvent ke){
                loadData();
            }
        });
        panel.add(pidTF);

        pnameL = new JLabel("PName :");
        pnameL.setBounds(120, 355, 200, 35);
        pnameL.setFont(new Font("Cambria", Font.BOLD, 30));
        pnameL.setForeground(Color.WHITE);
        panel.add(pnameL);

        pnameTF = new JLabel();
        pnameTF.setBounds(270, 355, 200, 35);
        pnameTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        pnameTF.setForeground(Color.WHITE);
        panel.add(pnameTF);

        quantityL = new JLabel("Available :");
        quantityL.setBounds(87, 420, 300, 35);
        quantityL.setFont(new Font("Cambria", Font.BOLD, 30));
        quantityL.setForeground(Color.WHITE);
        panel.add(quantityL);

        aquantityL = new JLabel();
        aquantityL.setBounds(270, 420, 100, 35);
        aquantityL.setFont(new Font("Cambria", Font.BOLD, 30));
        aquantityL.setForeground(Color.WHITE);
        panel.add(aquantityL);

        priceL = new JLabel("Price :");
        priceL.setBounds(147, 485, 200, 35);
        priceL.setFont(new Font("Cambria", Font.BOLD, 30));
        priceL.setForeground(Color.WHITE);
        panel.add(priceL);

        spriceL = new JLabel();
        spriceL.setBounds(270, 485, 200, 35);
        spriceL.setFont(new Font("Cambria", Font.BOLD, 30));
        spriceL.setForeground(Color.WHITE);
        panel.add(spriceL);

        amountL = new JLabel("Quantity* :");
        amountL.setBounds(85, 550, 200, 35);
        amountL.setFont(new Font("Cambria", Font.BOLD, 30));
        amountL.setForeground(Color.WHITE);
        panel.add(amountL);

        amountTF = new JTextField();
        amountTF.setBounds(270, 550, 200, 35);
        amountTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        amountTF.addKeyListener(new KeyAdapter(){
            public void keyReleased(KeyEvent ke){
                int quan = Integer.parseInt(amountTF.getText());

                if(quan > quantity){
                    JOptionPane.showMessageDialog(panel, "Sorry! NOT AVAILABLE");
                    amountTF.setText("");
                }

                else if(quan == 0 || quan < 0){
                    JOptionPane.showMessageDialog(panel, "ENTER VALID QUANTITY");
                    amountTF.setText("");
                }

                else{}
            }
        });
        panel.add(amountTF);

        addCart = new JButton("Add to Cart");
        addCart.setBounds(70, 615, 400, 40);
        addCart.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        addCart.setBackground(new Color(26, 163, 255));
        addCart.setForeground(Color.WHITE);
        addCart.addActionListener(this);
        panel.add(addCart);

        checkOut = new JButton("Check Out");
        checkOut.setBounds(70, 675, 400, 40);
        checkOut.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        checkOut.setBackground(new Color(26, 163, 255));
        checkOut.setForeground(Color.WHITE);
        checkOut.addActionListener(this);
        checkOut.setEnabled(false);
        panel.add(checkOut);

        logOut = new JButton("LOGOUT");
        logOut.setBounds(1155, 45, 100, 40);
        logOut.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        logOut.setBackground(new Color(26, 177, 136));
        logOut.setForeground(Color.WHITE);
        logOut.addActionListener(this);
        panel.add(logOut);

        back = new JButton("BACK");
        back.setBounds(100, 45, 100, 40);
        back.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        back.setBackground(new Color(26, 177, 136));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        panel.add(back);

        this.add(panel);
    }

    public void actionPerformed(ActionEvent ae){
        String str = ae.getActionCommand();

        if(str.equals(logOut.getText())){
            Login li = new Login();
            li.setVisible(true);
            this.setVisible(false);
        }

        else if(str.equals(back.getText())){
            CustomerHome ch = new CustomerHome(userId);
            ch.setVisible(true);
            this.setVisible(false);
        }

        else if(str.equals(refresh.getText())){
			pidTF.setText("");
			pnameTF.setText("");
			amountTF.setText("");
            aquantityL.setText("");
            spriceL.setText("");
        }

        else if(str.equals(addCart.getText())){
            insertDB();
            checkOut.setEnabled(true);
        }

        else if(str.equals(checkOut.getText())){
            CheckOut co = new CheckOut(userId);
            co.setVisible(true);
            this.setVisible(false);
        }

        else{}
    }

    public void insertDB(){
        String purchaseId = "" + rand.nextInt(5000) + 1;
        String productId = pidTF.getText();
        int quantity = Integer.parseInt(amountTF.getText());
        Double amount = Double.parseDouble(amountTF.getText()) * price;
        String date = "" + localDate;

        String query = "INSERT INTO purchaseinfo VALUES ('"+purchaseId+"','"+productId+"','"+userId+"',"+quantity+","+amount+",'"+date+"');";
		System.out.println(query);
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query);
			stm.close();
			con.close();
            JOptionPane.showMessageDialog(this, "Product Added!");
            
            updateQuantity();
			pidTF.setText("");
			pnameTF.setText("");
			amountTF.setText("");
            aquantityL.setText("");
            spriceL.setText("");
        } catch(Exception ex){
            JOptionPane.showMessageDialog(this, "Oops!");
        }
    }

    public void updateQuantity(){
        String loadId = pidTF.getText();
		int newQuantity = quantity - Integer.parseInt(amountTF.getText());
        
        String query = "UPDATE product SET availableQuantity="+newQuantity+" WHERE productId='"+loadId+"'";	
        Connection con=null;//for connection
        Statement st = null;//for query execution
        System.out.println(query);
        
        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			st = con.createStatement();//create statement
			st.executeUpdate(query);
			st.close();
			con.close();
        } catch(Exception ex){}
    }

    public void loadData(){
        String loadId = pidTF.getText();
        String query = "SELECT `productName`, `price`, `availableQuantity` FROM `product` WHERE `productId`='"+loadId+"';";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        System.out.println(query);

        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");
            
            String pname = null;
            boolean flag = false;

            while(rs.next()){
                pname = rs.getString("productName");
                quantity = rs.getInt("availableQuantity");
                price = rs.getDouble("price");
                flag = true;

                pnameTF.setText(pname);
                spriceL.setText("" + price);
                aquantityL.setText("" + quantity);
            }

            if(!flag){
                pnameTF.setText("");
                aquantityL.setText("");
                spriceL.setText("");
            }
        } catch(Exception ex){
            System.out.println("Exception : " + ex.getMessage());
        }

        finally{
            try{
                if(rs != null)
					rs.close();

                if(st != null)
					st.close();

                if(con != null)
					con.close();
            } catch(Exception ex){}
        }
    }

    public void showTableData(){
        String query = "SELECT `productId`, `productName` FROM product";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        System.out.println(query);

        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");

            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch(Exception ex){}

        finally{
            try{
                if(rs != null)
					rs.close();

                if(st != null)
					st.close();

                if(con != null)
					con.close();
            } catch(Exception ex){}
        }
    }
}