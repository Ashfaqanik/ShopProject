import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class CustomerHome extends JFrame implements ActionListener{
    private JPanel panel;
    private JLabel welcomeL, nameL, namesL, phoneL, phonesL, addressL, addresssL;
    private JButton logOut, updateInfo, buyProduct, orderList, deleteAccount;
    private String userId;

    public CustomerHome(String userId){
        super("Customer");

        this.userId = userId;
        this.setSize(1370, 750);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(36, 50, 61));

        welcomeL = new JLabel("Hello! " + userId);
        welcomeL.setBounds(450, 30, 600, 40);
        welcomeL.setFont(new Font("Siyam Rupali", Font.BOLD, 45));
        welcomeL.setForeground(Color.WHITE);
        panel.add(welcomeL);

        nameL = new JLabel("Name : ");
        nameL.setBounds(450, 150, 150, 30);
        nameL.setFont(new Font("Cambria", Font.BOLD, 30));
        nameL.setForeground(Color.WHITE);
        panel.add(nameL);

        namesL = new JLabel();
        namesL.setBounds(560, 150, 800, 30);
        namesL.setFont(new Font("Cambria", Font.BOLD, 25));
        namesL.setForeground(Color.WHITE);
        panel.add(namesL);

        phoneL = new JLabel("Phone Number : ");
        phoneL.setBounds(322, 200, 300, 30);
        phoneL.setFont(new Font("Cambria", Font.BOLD, 30));
        phoneL.setForeground(Color.WHITE);
        panel.add(phoneL);

        phonesL = new JLabel();
        phonesL.setBounds(560, 200, 500, 30);
        phonesL.setFont(new Font("Cambria", Font.BOLD, 25));
        phonesL.setForeground(Color.WHITE);
        panel.add(phonesL);

        addressL = new JLabel("Address : ");
        addressL.setBounds(415, 250, 500, 30);
        addressL.setFont(new Font("Cambria", Font.BOLD, 30));
        addressL.setForeground(Color.WHITE);
        panel.add(addressL);

        addresssL = new JLabel();
        addresssL.setBounds(560, 250, 800, 30);
        addresssL.setFont(new Font("Cambria", Font.BOLD, 25));
        addresssL.setForeground(Color.WHITE);
        panel.add(addresssL);

        loadDB();

        updateInfo = new JButton("Update Info");
        updateInfo.setBounds(480, 325, 200, 40);
        updateInfo.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        updateInfo.setBackground(new Color(51, 194, 78));
        updateInfo.setForeground(Color.WHITE);
        updateInfo.addActionListener(this);
        panel.add(updateInfo);

        buyProduct = new JButton("Buy Products");
        buyProduct.setBounds(480, 390, 200, 40);
        buyProduct.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        buyProduct.setBackground(new Color(51, 194, 78));
        buyProduct.setForeground(Color.WHITE);
        buyProduct.addActionListener(this);
        panel.add(buyProduct);

        orderList = new JButton("Order List");
        orderList.setBounds(480, 460, 200, 40);
        orderList.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        orderList.setBackground(new Color(51, 194, 78));
        orderList.setForeground(Color.WHITE);
        orderList.addActionListener(this);
        panel.add(orderList);

        deleteAccount = new JButton("Delete Account");
        deleteAccount.setBounds(450, 560, 260, 40);
        deleteAccount.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        deleteAccount.setBackground(new Color(255, 51, 51));
        deleteAccount.setForeground(Color.WHITE);
        deleteAccount.addActionListener(this);
        panel.add(deleteAccount);

        logOut = new JButton("LOGOUT");
        logOut.setBounds(1150, 30, 100, 40);
        logOut.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        logOut.setBackground(new Color(26, 177, 136));
        logOut.setForeground(Color.WHITE);
        logOut.addActionListener(this);
        panel.add(logOut);
       
        this.add(panel);
    }

	public void actionPerformed(ActionEvent ae){
        String str = ae.getActionCommand();

        if(str.equals(logOut.getText())){
            Login li = new Login();
            li.setVisible(true);
            this.setVisible(false);
        }

        else if(str.equals(deleteAccount.getText())){
            deleteBD();

            Login li = new Login();
            li.setVisible(true);
            this.setVisible(false);
        }

        else if(str.equals(updateInfo.getText())){
            cUpdateInfo ui = new cUpdateInfo(namesL.getText(), userId);
            ui.setVisible(true);
            this.setVisible(false);
        }

        else if(str.equals(buyProduct.getText())){
            ProductList pl = new ProductList(userId);
            pl.setVisible(true);
            this.setVisible(false);
        }

        else if(str.equals(orderList.getText())){
            OrderList ol = new OrderList(userId);
            ol.setVisible(true);
            this.setVisible(false);
        }

        else{}
    }

    public void loadDB(){
        String loadId = userId;
        String query = "SELECT `customerName`, `phoneNumber`, `address` FROM `customer` WHERE `userId`='"+loadId+"';";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        System.out.println(query);

        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");
            
            boolean flag = false;
            String cname = null;
            String phone = null; 
            String address = null;

            while(rs.next()){
                cname = rs.getString("customerName");
                phone = rs.getString("phoneNumber");
                address = rs.getString("address");
                flag = true;

                namesL.setText(cname);
                phonesL.setText(phone);
                addresssL.setText(address);
            }

            if(!flag){
                namesL.setText("");
                phonesL.setText("");
                addresssL.setText("");
            }
        } catch(Exception ex){
            System.out.println("Exception : " + ex.getMessage());
        }

        finally{
            try{
                if(rs != null)
					rs.close();

                if(st != null)
					st.close();

                if(con != null)
					con.close();
            } catch(Exception ex){}
        }
    }

    public void deleteBD(){
        String newId = userId;
        String query1 = "DELETE from customer WHERE userId='"+newId+"';";
		String query2 = "DELETE from login WHERE userId='"+newId+"';";
		System.out.println(query1);
        System.out.println(query2);
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query1);
			stm.execute(query2);
			stm.close();
            con.close();
            JOptionPane.showMessageDialog(this, "Account Deleted");
        } catch(Exception ex){}
    }
}