import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class CustomerInfo extends JFrame implements ActionListener{
    private JPanel panel;
    private String userId;
    private JLabel welcomeL, customerL, userL, nameL, phoneL, addressL, namesL, phonesL, addresssL;
    private JButton back, search, logOut;
    private JTextField userTF;

    public CustomerInfo(String userId){
        super("Customer Information");

        this.userId = userId;
        this.setSize(1370, 750);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(36, 50, 61));

        Font f1 = new Font("Cambria", Font.BOLD, 20);

        welcomeL = new JLabel(userId);
        welcomeL.setBounds(550, 30, 600, 40);
        welcomeL.setFont(new Font("Siyam Rupali", Font.BOLD, 45));
        welcomeL.setForeground(Color.WHITE);
        panel.add(welcomeL);

        customerL = new JLabel("Search Customers!");
        customerL.setBounds(385, 100, 600, 60);
        customerL.setFont(new Font("Siyam Rupali", Font.BOLD, 50));
        customerL.setForeground(Color.WHITE);
        panel.add(customerL);

        userL = new JLabel("UserId : ");
        userL.setBounds(420, 200, 150, 30);
        userL.setFont(new Font("Cambria", Font.BOLD, 30));
        userL.setForeground(Color.WHITE);
        panel.add(userL);

        userTF = new JTextField();
        userTF.setBounds(560, 200, 150, 30);
        userTF.setFont(new Font("Cambria", Font.BOLD, 20));
        userTF.setForeground(Color.BLACK);
        panel.add(userTF);

        nameL = new JLabel("Name : ");
        nameL.setBounds(433, 260, 300, 30);
        nameL.setFont(new Font("Cambria", Font.BOLD, 30));
        nameL.setForeground(Color.WHITE);
        panel.add(nameL);

        namesL = new JLabel();
        namesL.setBounds(560, 260, 500, 30);
        namesL.setFont(new Font("Cambria", Font.BOLD, 25));
        namesL.setForeground(Color.WHITE);
        panel.add(namesL);

        phoneL = new JLabel("Phone Number : ");
        phoneL.setBounds(305, 310, 500, 30);
        phoneL.setFont(new Font("Cambria", Font.BOLD, 30));
        phoneL.setForeground(Color.WHITE);
        panel.add(phoneL);

        phonesL = new JLabel();
        phonesL.setBounds(560, 310, 800, 30);
        phonesL.setFont(new Font("Cambria", Font.BOLD, 25));
        phonesL.setForeground(Color.WHITE);
        panel.add(phonesL);

        addressL = new JLabel("Address : ");
        addressL.setBounds(398, 360, 500, 30);
        addressL.setFont(new Font("Cambria", Font.BOLD, 30));
        addressL.setForeground(Color.WHITE);
        panel.add(addressL);

        addresssL = new JLabel();
        addresssL.setBounds(560, 360, 800, 30);
        addresssL.setFont(new Font("Cambria", Font.BOLD, 25));
        addresssL.setForeground(Color.WHITE);
        panel.add(addresssL);

        back = new JButton("BACK");
		back.setBounds(500, 440, 115, 45);
		back.setFont(f1);
		back.setBackground(new Color(51, 194, 78));
		back.setForeground(Color.WHITE);
		back.addActionListener(this);
		panel.add(back);

		search = new JButton("SEARCH");
		search.setBounds(635, 440, 115, 45);
		search.setFont(f1);
		search.setBackground(new Color(51, 194, 78));
		search.setForeground(Color.WHITE);
		search.addActionListener(this);
		panel.add(search);

        logOut = new JButton("LOGOUT");
        logOut.setBounds(1155, 30, 100, 40);
        logOut.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        logOut.setBackground(new Color(26, 177, 136));
        logOut.setForeground(Color.WHITE);
        logOut.addActionListener(this);
        panel.add(logOut);

        this.add(panel);

    }

    public void actionPerformed(ActionEvent ae){
        String str = ae.getActionCommand();

        if(str.equals(logOut.getText())){
            Login li = new Login();
            li.setVisible(true);
            this.setVisible(false);
        }

        else if(str.equals(search.getText())){
            loadDB();
        }

        else if(str.equals(back.getText())){
            checkEmployee();
        }

        else{}
    }

    public void loadDB(){
        String loadId = userTF.getText();
        String query = "SELECT `customerName`, `phoneNumber`, `address` FROM `customer` WHERE `userId`='"+loadId+"';";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        System.out.println(query);

        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");
                       
            String cname = null;
            String phone = null; 
            String address = null;
            boolean flag = false;

            while(rs.next()){
                cname = rs.getString("customerName");
                phone = rs.getString("phoneNumber");
                address = rs.getString("address");
                flag = true;

                namesL.setText(cname);
                phonesL.setText(phone);
                addresssL.setText(address);
            }

            if(!flag){
                namesL.setText("");
                phonesL.setText("");
                addresssL.setText("");
            }
        } catch(Exception ex){
            System.out.println("Exception : " + ex.getMessage());
        }

        finally{
            try{
                if(rs != null)
					rs.close();

                if(st != null)
					st.close();

                if(con != null)
					con.close();
            } catch(Exception ex){}
        }
    }

    public void checkEmployee(){
        String query = "SELECT `role` FROM `employee` WHERE `userId`='"+userId+"';";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        System.out.println(query);

        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");

            while(rs.next()){
                String role = rs.getString("role");

                if(role.equals("Employee")){
                    EmployeeHome eh = new EmployeeHome(userId);
                    eh.setVisible(true);
                    this.setVisible(false);
                }

                else if(role.equals("Manager")){
                    ManagerHome mh = new ManagerHome(userId);
                    mh.setVisible(true);
                    this.setVisible(false);
                }

                else{}
            }
        } catch(Exception ex){}

        finally{
            try{
                if(rs != null)
                    rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            } catch(Exception ex){}
        }
    }
}