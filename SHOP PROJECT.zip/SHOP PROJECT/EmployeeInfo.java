import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class EmployeeInfo extends JFrame implements ActionListener{
    private JTextField userTF, passTF, nameTF, phoneTF, roleTF, salaryTF;
    private JButton search, update, delete, back, logOut, refresh, add;
    private JLabel userL, passL, nameL, phoneL, roleL, salaryL;
    private JPanel panel;
    private String userId;

    public EmployeeInfo(String userId){
        super("Employess");

        this.userId = userId;
        this.setSize(1370, 750);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(36, 50, 61));

        Font f1 = new Font("Cambria", Font.BOLD, 20);

        refresh = new JButton("REFRESH");
		refresh.setBounds(550, 50, 275, 45);
		refresh.setFont(f1);
		refresh.setBackground(new Color(51, 194, 78));
        refresh.setForeground(Color.WHITE);
        refresh.addActionListener(this);
		panel.add(refresh);

        userL = new JLabel("userId :");
        userL.setBounds(528, 150, 300, 30);
        userL.setFont(new Font("Cambria", Font.BOLD, 30));
        userL.setForeground(Color.WHITE);
        panel.add(userL);

        userTF = new JTextField();
        userTF.setBounds(660, 150, 200, 30);
        userTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(userTF);

        search = new JButton("SEARCH");
		search.setBounds(890, 150, 150, 30);
		search.setFont(new Font("Cambria", Font.BOLD, 20));
		search.setBackground(new Color(51, 194, 78));
        search.setForeground(Color.WHITE);
        search.addActionListener(this);
		panel.add(search);

        nameL = new JLabel("Full Name :");
        nameL.setBounds(480, 210, 300, 30);
        nameL.setFont(new Font("Cambria", Font.BOLD, 30));
        nameL.setForeground(Color.WHITE);
        panel.add(nameL);

        nameTF = new JTextField();
        nameTF.setBounds(660, 210, 200, 30);
        nameTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(nameTF);

        passL = new JLabel("password :");
        passL.setBounds(482, 270, 300, 30);
        passL.setFont(new Font("Cambria", Font.BOLD, 30));
        passL.setForeground(Color.WHITE);
        panel.add(passL);

        passTF = new JTextField();
        passTF.setBounds(660, 270, 200, 30);
        passTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(passTF);

        phoneL = new JLabel("Phone Number :");
        phoneL.setBounds(409, 330, 300, 30);
        phoneL.setFont(new Font("Cambria", Font.BOLD, 30));
        phoneL.setForeground(Color.WHITE);
        panel.add(phoneL);

        phoneTF = new JTextField();
        phoneTF.setBounds(660, 330, 200, 30);
        phoneTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(phoneTF);

        roleL = new JLabel("Role :");
        roleL.setBounds(552, 390, 300, 30);
        roleL.setFont(new Font("Cambria", Font.BOLD, 30));
        roleL.setForeground(Color.WHITE);
        panel.add(roleL);

        roleTF = new JTextField();
        roleTF.setBounds(660, 390, 200, 30);
        roleTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(roleTF);

        salaryL = new JLabel("Salary :");
        salaryL.setBounds(530, 450, 300, 30);
        salaryL.setFont(new Font("Cambria", Font.BOLD, 30));
        salaryL.setForeground(Color.WHITE);
        panel.add(salaryL);

        salaryTF = new JTextField();
        salaryTF.setBounds(660, 450, 200, 30);
        salaryTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(salaryTF);

        add = new JButton("ADD");
		add.setBounds(450, 550, 135, 45);
		add.setFont(f1);
		add.setBackground(new Color(51, 194, 78));
        add.setForeground(Color.WHITE);
        add.addActionListener(this);
        panel.add(add);
        
        update = new JButton("UPDATE");
		update.setBounds(600, 550, 150, 45);
		update.setFont(f1);
		update.setBackground(new Color(51, 194, 78));
        update.setForeground(Color.WHITE);
        update.setEnabled(false);
        update.addActionListener(this);
        panel.add(update);
        
        delete = new JButton("DELETE");
		delete.setBounds(765, 550, 150, 45);
		delete.setFont(f1);
		delete.setBackground(new Color(255, 51, 51));
        delete.setForeground(Color.WHITE);
        delete.setEnabled(false);
        delete.addActionListener(this);
        panel.add(delete);

        back = new JButton("BACK");
        back.setBounds(100, 45, 100, 40);
        back.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        back.setBackground(new Color(26, 177, 136));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        panel.add(back);
        
        logOut = new JButton("LOGOUT");
        logOut.setBounds(1150, 50, 100, 40);
        logOut.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        logOut.setBackground(new Color(26, 177, 136));
        logOut.setForeground(Color.WHITE);
        logOut.addActionListener(this);
        panel.add(logOut);

        this.add(panel);
    }

    public void actionPerformed(ActionEvent ae){
        String text = ae.getActionCommand();
		
		if(text.equals(back.getText())){
            ManagerHome mh = new ManagerHome(userId);
            mh.setVisible(true);
            this.setVisible(false);
        }

        else if(text.equals(logOut.getText())){
            Login li = new Login();
            li.setVisible(true);
            this.setVisible(false);
        }

        else if(text.equals(search.getText())){
            loadDB();
        }

        else if(text.equals(refresh.getText())){
            update.setEnabled(false);
            delete.setEnabled(false);
            add.setEnabled(true);
            userTF.setEnabled(true);
            passTF.setEnabled(true);
			userTF.setText("");
			nameTF.setText("");
			phoneTF.setText("");
			roleTF.setText("");
			salaryTF.setText("");
        }

        else if(text.equals(update.getText())){
            updateDB();
        }

        else if(text.equals(delete.getText())){
            deleteDB();
        }

        else if(text.equals(add.getText())){
            insertDB();
        }

        else{}
    }

    public void insertDB(){
        String newUser = userTF.getText();
        String newName = nameTF.getText();
        String newPass = passTF.getText();
        String newPhone = phoneTF.getText();
        String newRole = roleTF.getText();
        Double newSalary = Double.parseDouble(salaryTF.getText());
        int status = 0;

        String query1 = "INSERT INTO employee VALUES ('"+newUser+"','"+newName+"','"+ newPhone+"','"+newRole+"',"+newSalary+");";
		String query2 = "INSERT INTO login VALUES ('"+newUser+"','"+newPass+"',"+status+");";
		System.out.println(query1);
        System.out.println(query2);
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query1);
			stm.execute(query2);
			stm.close();
			con.close();
            JOptionPane.showMessageDialog(this, "Account Added!");
            
            update.setEnabled(false);
            delete.setEnabled(false);
            add.setEnabled(true);
            userTF.setEnabled(true);
            passTF.setEnabled(true);
			userTF.setText("");
			nameTF.setText("");
			phoneTF.setText("");
			roleTF.setText("");
			salaryTF.setText("");
        } catch(Exception ex){
            JOptionPane.showMessageDialog(this, "Oops!");
        }
    }

    public void loadDB(){
        String loadId = userTF.getText();
		String query = "SELECT `employeeName`, `phoneNumber`, `role`, `salary` FROM `employee` WHERE `userId`='"+loadId+"';";     
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
        System.out.println(query);
        
        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");
            
            boolean flag = false;
			String ename = null;
			String phone = null;
			String role = null;
            double salary = 0.0;
            
            while(rs.next()){
                ename = rs.getString("employeeName");
				phone = rs.getString("phoneNumber");
				role = rs.getString("role");
				salary = rs.getDouble("salary");
                flag=true;
                
                nameTF.setText(ename);
                phoneTF.setText(phone);
                roleTF.setText(role);
                salaryTF.setText("" + salary);
                userTF.setEnabled(false);
                passTF.setEnabled(false);
                update.setEnabled(true);
                delete.setEnabled(true);
                add.setEnabled(false);
            }

            if(!flag){
                nameTF.setText("");
				phoneTF.setText("");
				roleTF.setText("");
				salaryTF.setText("");
				JOptionPane.showMessageDialog(this,"Invalid ID");
            }
        } catch(Exception ex){}

        finally{
            try{
                if(rs!=null)
					rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            } catch(Exception ex){}
        }
    }

    public void updateDB(){
        String loadId = userTF.getText();
		String newName = nameTF.getText();
		String newPhone = phoneTF.getText();
		String newRole = roleTF.getText();
        double newSalary = 0.0;
        
        try{
            newSalary = Double.parseDouble(salaryTF.getText());
        } catch(Exception e){}

        String query = "UPDATE employee SET employeeName='"+newName+"', phoneNumber = '"+newPhone+"', role = '"+newRole+"', salary = "+newSalary+" WHERE userId='"+loadId+"'";	
        Connection con=null;//for connection
        Statement st = null;//for query execution
        System.out.println(query);
        
        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			st = con.createStatement();//create statement
			st.executeUpdate(query);
			st.close();
			con.close();
            JOptionPane.showMessageDialog(this, "Account Updated!");
            
            update.setEnabled(false);
            delete.setEnabled(false);
            add.setEnabled(true);
            userTF.setEnabled(true);
            passTF.setEnabled(true);
			userTF.setText("");
			nameTF.setText("");
			phoneTF.setText("");
			roleTF.setText("");
			salaryTF.setText("");
        } catch(Exception ex){}
    }

    public void deleteDB(){
        String loadId = userTF.getText();
		String query1 = "DELETE from employee WHERE userId='"+loadId+"';";
		String query2 = "DELETE from login WHERE userId='"+loadId+"';";
		System.out.println(query1);
        System.out.println(query2);
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query1);
			stm.execute(query2);
			stm.close();
			con.close();
            JOptionPane.showMessageDialog(this, "Account Deleted!");
            
            update.setEnabled(false);
            delete.setEnabled(false);
            add.setEnabled(true);
            userTF.setEnabled(true);
            passTF.setEnabled(true);
			userTF.setText("");
			nameTF.setText("");
			phoneTF.setText("");
			roleTF.setText("");
			salaryTF.setText("");
        } catch(Exception ex){}
    }
}
