import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ManagerHome extends JFrame implements ActionListener{
    private JPanel panel;
    private JLabel welcomeL, nameL, namesL, phoneL, phonesL, roleL, rolesL, salaryL, salarysL;
    private JButton logOut, updateInfo, customer, product, employee;
    private String userId;

    public ManagerHome(String userId){
        super("Manager");

        this.userId = userId;
        this.setSize(1380, 750);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(36, 50, 61));

        welcomeL = new JLabel(userId);
        welcomeL.setBounds(530, 50, 400, 40);
        welcomeL.setFont(new Font("Siyam Rupali", Font.BOLD, 45));
        welcomeL.setForeground(Color.WHITE);
        panel.add(welcomeL);

        nameL = new JLabel("Name : ");
        nameL.setBounds(450, 150, 150, 30);
        nameL.setFont(new Font("Cambria", Font.BOLD, 30));
        nameL.setForeground(Color.WHITE);
        panel.add(nameL);

        namesL = new JLabel();
        namesL.setBounds(560, 150, 800, 30);
        namesL.setFont(new Font("Cambria", Font.BOLD, 25));
        namesL.setForeground(Color.WHITE);
        panel.add(namesL);

        phoneL = new JLabel("Phone Number : ");
        phoneL.setBounds(322, 200, 300, 30);
        phoneL.setFont(new Font("Cambria", Font.BOLD, 30));
        phoneL.setForeground(Color.WHITE);
        panel.add(phoneL);

        phonesL = new JLabel();
        phonesL.setBounds(560, 200, 500, 30);
        phonesL.setFont(new Font("Cambria", Font.BOLD, 25));
        phonesL.setForeground(Color.WHITE);
        panel.add(phonesL);

        roleL = new JLabel("Role : ");
        roleL.setBounds(467, 250, 100, 30);
        roleL.setFont(new Font("Cambria", Font.BOLD, 30));
        roleL.setForeground(Color.WHITE);
        panel.add(roleL);

        rolesL = new JLabel();
        rolesL.setBounds(560, 250, 500, 30);
        rolesL.setFont(new Font("Cambria", Font.BOLD, 25));
        rolesL.setForeground(Color.WHITE);
        panel.add(rolesL);

        salaryL = new JLabel("Salary : ");
        salaryL.setBounds(442, 300, 150, 35);
        salaryL.setFont(new Font("Cambria", Font.BOLD, 30));
        salaryL.setForeground(Color.WHITE);
        panel.add(salaryL);

        salarysL = new JLabel();
        salarysL.setBounds(560, 300, 500, 35);
        salarysL.setFont(new Font("Cambria", Font.BOLD, 25));
        salarysL.setForeground(Color.WHITE);
        panel.add(salarysL);

        loadDB();

        updateInfo = new JButton("Update Info");
        updateInfo.setBounds(490, 380, 200, 40);
        updateInfo.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        updateInfo.setBackground(new Color(51, 194, 78));
        updateInfo.setForeground(Color.WHITE);
        updateInfo.addActionListener(this);
        panel.add(updateInfo);

        logOut = new JButton("LOGOUT");
        logOut.setBounds(1155, 45, 100, 40);
        logOut.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        logOut.setBackground(new Color(26, 177, 136));
        logOut.setForeground(Color.WHITE);
        logOut.addActionListener(this);
        panel.add(logOut);

        employee = new JButton("Employees");
        employee.setBounds(490, 450, 200, 40);
        employee.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        employee.setBackground(new Color(51, 194, 78));
        employee.setForeground(Color.WHITE);
        employee.addActionListener(this);
        panel.add(employee);

        customer = new JButton("Customers");
        customer.setBounds(490, 510, 200, 40);
        customer.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        customer.setBackground(new Color(51, 194, 78));
        customer.setForeground(Color.WHITE);
        customer.addActionListener(this);
        panel.add(customer);

        product = new JButton("Products");
        product.setBounds(490, 580, 200, 40);
        product.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        product.setBackground(new Color(51, 194, 78));
        product.setForeground(Color.WHITE);
        product.addActionListener(this);
        panel.add(product);

        this.add(panel);
    }

    public void actionPerformed(ActionEvent ae){
        String str = ae.getActionCommand();

        if(str.equals(logOut.getText())){
            Login li = new Login();
            li.setVisible(true);
            this.setVisible(false);
        }

        else if(str.equals(updateInfo.getText())){
            eUpdateInfo ui = new eUpdateInfo(namesL.getText(), userId);
            ui.setVisible(true);
            this.setVisible(false);
        }

        else if(str.equals(customer.getText())){
            CustomerInfo ci = new CustomerInfo(userId);
            ci.setVisible(true);
            this.setVisible(false);
        }

        else if(str.equals(employee.getText())){
            EmployeeInfo ei = new EmployeeInfo(userId);
            ei.setVisible(true);
            this.setVisible(false);
        }

        else if(str.equals(product.getText())){
            ProductInfo pi = new ProductInfo(userId);
            pi.setVisible(true);
            this.setVisible(false);
        }

        else{}
    }

    public void loadDB(){
        String loadId = userId;
        String query = "SELECT `employeeName`, `phoneNumber`, `role`, `salary` FROM `employee` WHERE `userId`='"+loadId+"';";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        System.out.println(query);

        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");
            
            boolean flag = false;
            String cname = null;
            String phone = null; 
            String role = null;
            String salary = null;

            while(rs.next()){
                cname = rs.getString("employeeName");
                phone = rs.getString("phoneNumber");
                role = rs.getString("role");
                salary = rs.getString("salary");
                flag = true;

                namesL.setText(cname);
                phonesL.setText(phone);
                rolesL.setText(role);
                salarysL.setText(salary);
            }

            if(!flag){
                namesL.setText("");
                phonesL.setText("");
                rolesL.setText("");
                salarysL.setText("");
            }
        } catch(Exception ex){
            System.out.println("Exception : " + ex.getMessage());
        }

        finally{
            try{
                if(rs != null)
					rs.close();

                if(st != null)
					st.close();

                if(con != null)
					con.close();
            } catch(Exception ex){}
        }
    }
}