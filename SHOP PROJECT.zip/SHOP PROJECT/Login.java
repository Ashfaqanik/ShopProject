import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener{
	private JTextField userTF;
	private JPasswordField passTF;
	private JButton login, signup, exit;
	private JPanel panel;
	private ImageIcon img;
	private JLabel imgLabel;

	public Login(){
		super("TAZ SHOP");

		this.setSize(1370, 750);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		panel = new JPanel();
		panel.setLayout(null);

		Font f1 = new Font("Cambria", Font.BOLD, 15);

		userTF = new JTextField();
		userTF.setBounds(550, 275, 250, 30);
		userTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
		panel.add(userTF);

		passTF = new JPasswordField();
		passTF.setBounds(550, 315, 250, 30);
		passTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
		passTF.setEchoChar('*');
		panel.add(passTF);

		login = new JButton("LOGIN");
		login.setBounds(550, 365, 115, 40);
		login.setFont(f1);
		login.setBackground(new Color(51, 194, 78));
		login.setForeground(Color.WHITE);
		login.addActionListener(this);
		panel.add(login);

		signup = new JButton("SIGN UP");
		signup.setBounds(685, 365, 115, 40);
		signup.setFont(f1);
		signup.setBackground(new Color(51, 194, 78));
		signup.setForeground(Color.WHITE);
		signup.addActionListener(this);
		panel.add(signup);

		exit = new JButton("EXIT");
		exit.setBounds(550, 425, 250, 40);
		exit.setFont(f1);
		exit.setBackground(new Color(51, 194, 78));
		exit.setForeground(Color.WHITE);
		exit.addActionListener(this);
		panel.add(exit);

		img = new ImageIcon("welcome.jpg");
		imgLabel = new JLabel(img);
		imgLabel.setBounds(0, 0, 1370, 750);
		panel.add(imgLabel);

		this.add(panel);
	}

	public void actionPerformed(ActionEvent ae){
		String text = ae.getActionCommand();

		if(text.equals(login.getText())){
			checkLogin();
		}
		
		else if(text.equals(signup.getText())){
			Signup sp = new Signup();
            sp.setVisible(true);
            this.setVisible(false);
		}
		
		else if(text.equals(exit.getText())){
			System.exit(0);
		}

		else{}
	}

	public void checkLogin(){
		String query = "SELECT `userId`, `password`, `status` FROM `login`;";    
        Connection con = null;
		Statement st = null;
		ResultSet rs = null;

		System.out.println(query);

		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver loaded");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");

			st = con.createStatement();
			System.out.println("statement created");

			rs = st.executeQuery(query);
			System.out.println("results received");
			
			boolean flag = false;	
			
			while(rs.next()){
				String userId = rs.getString("userId");
                String password = rs.getString("password");
				int status = rs.getInt("status");
				
				if(userId.equals(userTF.getText()) && password.equals(passTF.getText())){
					flag = true;

					if(status == 0){
						EmployeeHome eh = new EmployeeHome(userId);
						eh.setVisible(true);
						this.setVisible(false);
					}

					else if(status == 1){
						CustomerHome ch = new CustomerHome(userId);
						ch.setVisible(true);
						this.setVisible(false);
					}

					else if(status == 2){
						ManagerHome mh = new ManagerHome(userId);
						mh.setVisible(true);
						this.setVisible(false);
					}

					else{}
				}
			}
			if(!flag){
				JOptionPane.showMessageDialog(this,"Invalid ID or Password");
			}
		} catch(Exception ex){
			System.out.println("Exception : " + ex.getMessage());
		}

		finally{
			try{
				if(rs!=null)
					rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
			} catch(Exception ex){}
		}
	}
}