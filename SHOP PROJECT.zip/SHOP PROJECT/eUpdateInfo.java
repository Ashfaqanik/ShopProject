import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class eUpdateInfo extends JFrame implements ActionListener{
    private JTextField userTF, passTF, nameTF, phoneTF;
    private JButton update, back, logOut;
    private JLabel welcomeL, userL, passL, nameL, phoneL;
    private JPanel panel;
    private String name, userId;

    public eUpdateInfo(String name, String userId){
        super("UpdateInfo Form");

        this.name = name;
        this.userId = userId;
        this.setSize(1370, 750);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(36, 50, 61));

        Font f1 = new Font("Cambria", Font.BOLD, 20);

        welcomeL = new JLabel(name);
        welcomeL.setBounds(500, 110, 1000, 40);
        welcomeL.setFont(new Font("Siyam Rupali", Font.BOLD, 45));
        welcomeL.setForeground(Color.WHITE);
        panel.add(welcomeL);

        userL = new JLabel("userId :");
        userL.setBounds(528, 250, 300, 30);
        userL.setFont(new Font("Cambria", Font.BOLD, 30));
        userL.setForeground(Color.WHITE);
        panel.add(userL);

        userTF = new JTextField();
        userTF.setText(userId);
        userTF.setEditable(false);
        userTF.setBounds(660, 250, 200, 30);
        userTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(userTF);
        
        nameL = new JLabel("Name :");
        nameL.setBounds(537, 300, 300, 30);
        nameL.setFont(new Font("Cambria", Font.BOLD, 30));
        nameL.setForeground(Color.WHITE);
        panel.add(nameL);

        nameTF = new JTextField();
        nameTF.setBounds(660, 300, 200, 30);
        nameTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(nameTF);

        passL = new JLabel("password :");
        passL.setBounds(482, 350, 300, 30);
        passL.setFont(new Font("Cambria", Font.BOLD, 30));
        passL.setForeground(Color.WHITE);
        panel.add(passL);

        passTF = new JTextField();
        passTF.setBounds(660, 350, 200, 30);
        passTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(passTF);

        phoneL = new JLabel("Phone Number :");
        phoneL.setBounds(407, 400, 300, 30);
        phoneL.setFont(new Font("Cambria", Font.BOLD, 30));
        phoneL.setForeground(Color.WHITE);
        panel.add(phoneL);

        phoneTF = new JTextField();
        phoneTF.setBounds(660, 400, 200, 30);
        phoneTF.setFont(new Font("Siyam Rupali", Font.BOLD, 20));
        panel.add(phoneTF);

        back = new JButton("BACK");
		back.setBounds(535, 500, 135, 45);
		back.setFont(f1);
		back.setBackground(new Color(51, 194, 78));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
		panel.add(back);

		update = new JButton("UPDATE");
		update.setBounds(700, 500, 135, 45);
		update.setFont(f1);
		update.setBackground(new Color(51, 194, 78));
		update.setForeground(Color.WHITE);
		update.addActionListener(this);
        panel.add(update);
        
        logOut = new JButton("LOGOUT");
        logOut.setBounds(1150, 30, 100, 40);
        logOut.setFont(new Font("Siyam Rupali", Font.BOLD, 15));
        logOut.setBackground(new Color(26, 177, 136));
        logOut.setForeground(Color.WHITE);
        logOut.addActionListener(this);
        panel.add(logOut);

        loadDB();
        loadPass();

        this.add(panel);
    }

    public void actionPerformed(ActionEvent ae){
        String str = ae.getActionCommand();

        if(str.equals(logOut.getText())){
            Login li = new Login();
            li.setVisible(true);
            this.setVisible(false);
        }

        else if(str.equals(back.getText())){
            checkEmployee();
        }

        else if(str.equals(update.getText())){
            updateDB();

            checkEmployee(); 
        }

        else{}
    }

    public void updateDB(){
        String newName = nameTF.getText();
        String newPass = passTF.getText();
        String newphone = phoneTF.getText();

        String query1 = "UPDATE employee SET employeeName='"+newName+"', phoneNumber = '"+newphone+"' WHERE userId='"+userId+"'";	
        String query2 = "UPDATE login SET password='"+newPass+"' WHERE userId='"+userId+"'";
        Connection con=null;//for connection
        Statement st = null;//for query execution
        System.out.println(query1);
        System.out.println(query2);

        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			st = con.createStatement();//create statement
            st.executeUpdate(query1);
            st.executeUpdate(query2);
			st.close();
			con.close();
			JOptionPane.showMessageDialog(this, "Successful!");
        } catch(Exception ex){}
    }

    public void loadDB(){
		String query = "SELECT `employeeName`, `phoneNumber` FROM `employee` WHERE `userId`='"+userId+"';";     
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
        System.out.println(query);
        
        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");
            
            boolean flag = false;
			String ename = null;
			String phone = null;
            
            while(rs.next()){
                ename = rs.getString("employeeName");
				phone = rs.getString("phoneNumber");
                flag=true;
                
                nameTF.setText(ename);
                phoneTF.setText(phone);
                userTF.setEnabled(false);
            }

            if(!flag){
                nameTF.setText("");
				phoneTF.setText("");
				JOptionPane.showMessageDialog(this,"Invalid ID");
            }
        } catch(Exception ex){}

        finally{
            try{
                if(rs!=null)
					rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            } catch(Exception ex){}
        }
    }

    public void loadPass(){
		String query = "SELECT `password` FROM `login` WHERE `userId`='"+userId+"';";     
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
        System.out.println(query);
        
        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");
            
            boolean flag = false;
			String pass = null;
            
            while(rs.next()){
                pass = rs.getString("password");
                flag=true;
                
                passTF.setText(pass);
            }

            if(!flag){
                passTF.setText("");
				JOptionPane.showMessageDialog(this,"Invalid ID");
            }
        } catch(Exception ex){}

        finally{
            try{
                if(rs!=null)
					rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            } catch(Exception ex){}
        }
    }

    public void checkEmployee(){
        String query = "SELECT `role` FROM `employee` WHERE `userId`='"+userId+"';";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        System.out.println(query);

        try{
            Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/e12","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
            System.out.println("results received");

            while(rs.next()){
                String role = rs.getString("role");

                if(role.equals("Employee")){
                    EmployeeHome eh = new EmployeeHome(userId);
                    eh.setVisible(true);
                    this.setVisible(false);
                }

                else if(role.equals("Manager")){
                    ManagerHome mh = new ManagerHome(userId);
                    mh.setVisible(true);
                    this.setVisible(false);
                }

                else{}
            }
        } catch(Exception ex){}

        finally{
            try{
                if(rs != null)
                    rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            } catch(Exception ex){}
        }
    }
}